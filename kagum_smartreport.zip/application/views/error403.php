<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>403 Forbidden</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="<?php echo base_url();?>assets/403/style.css">
</head>
<body>
<!-- partial:index.partial.html -->
<div class="container">
  <h1>4<div class="lock">
		<div class="top"></div><div class="bottom"></div>
    </div>3</h1><p>Access denied </p>
</div>
<!-- partial -->
  <script  src="<?php echo base_url();?>assets/403/script.js"></script>

</body>
</html>