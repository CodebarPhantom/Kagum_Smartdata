            <div class="navbar navbar-expand-lg navbar-light">
				<div class="text-center d-lg-none w-100">
					<button type="button" class="navbar-toggler dropdown-toggle" data-toggle="collapse" data-target="#navbar-footer">
						<i class="icon-unfold mr-2"></i>
						Footer
					</button>
				</div>

				<div class="navbar-collapse collapse" id="navbar-footer">
					<span class="navbar-text">
						&copy; 2019 - <?php echo date('Y'); ?>. <a href="#">Kagum Hotels Smart Report</a> by <a href="https://id.linkedin.com/in/eryan-fauzan-1ba086190" target="_blank">Eryan Fauzan</a> Theme using <a href="#" target="_blank">Limitless Web App Kit</a>
					</span>

					<ul class="navbar-nav ml-lg-auto">
						<li class="nav-item"><a href="#" class="navbar-nav-link" target="_blank"><i class="icon-display mr-2"></i>IT Programmer</a></li>
						
					</ul>
				</div>
			</div>